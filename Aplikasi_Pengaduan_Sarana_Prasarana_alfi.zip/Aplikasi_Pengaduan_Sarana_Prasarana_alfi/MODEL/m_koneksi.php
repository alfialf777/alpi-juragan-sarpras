<?php

class Koneksi
{
    // konfigurasi database
    private $host = "127.0.0.1";
    private $username = "root";
    private $password = "root";
    private $db = "pengaduan_sarpras_alfi";

    public $koneksi;

    // constructor
    function __construct()
    {
        // membuat koneksi
        $this->koneksi = mysqli_connect(
            $this->host,
            $this->username,
            $this->password,
            $this->db
        );

        // cek koneksi
        if (!$this->koneksi) {
            die("Koneksi database gagal: " . mysqli_connect_error());
        }
    }
}
?>