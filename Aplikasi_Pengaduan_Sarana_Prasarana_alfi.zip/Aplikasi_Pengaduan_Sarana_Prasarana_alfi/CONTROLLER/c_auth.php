<?php

session_start();

require_once '../MODEL/m_siswa.php';
require_once '../MODEL/m_admin.php';


class AuthController
{
    private $siswaModel;
    private $adminModel;


    // CONSTRUCTOR
    public function __construct()
    {
        $this->siswaModel = new Siswa();
        $this->adminModel = new Admin();
    }


    // ==================================================
    // LOGIN GABUNGAN
    // ==================================================

    public function login($username, $password)
    {
        // Cek sebagai siswa
        // Untuk siswa, input username adalah NIS
        $siswa = $this->siswaModel->login($username, $password);

        if ($siswa) {

            // Hapus session admin
            unset($_SESSION['admin']);
            unset($_SESSION['id_admin']);
            unset($_SESSION['username']);
            unset($_SESSION['nama_lengkap']);

            // Buat session siswa
            $_SESSION['siswa'] = true;
            $_SESSION['nis'] = $siswa['nis'];
            $_SESSION['nama'] = $siswa['nama'];
            $_SESSION['kelas'] = $siswa['kelas'];

            // Dashboard siswa
            header("Location: ../VIEW/SISWA/dasbord_siswa.php");
            exit();
        }


        // Kalau bukan siswa, cek sebagai admin
        $admin = $this->adminModel->login($username, $password);

        if ($admin) {

            // Hapus session siswa
            unset($_SESSION['siswa']);
            unset($_SESSION['nis']);
            unset($_SESSION['nama']);
            unset($_SESSION['kelas']);

            // Buat session admin
            $_SESSION['admin'] = true;
            $_SESSION['id_admin'] = $admin['id_admin'];
            $_SESSION['username'] = $admin['username'];
            $_SESSION['nama_lengkap'] = $admin['nama_lengkap'];

            // Dashboard admin
            header("Location: ../VIEW/ADMIN/v_dasbord_admin.php");
            exit();
        }


        // Kalau siswa dan admin sama-sama tidak ditemukan
        $_SESSION['error'] = "NIS/Username atau password salah!";

        header("Location: ../VIEW/auth/v_login.php");
        exit();
    }


    // ==================================================
    // LOGIN SISWA LAMA
    // ==================================================

    public function loginSiswa($nis, $password)
    {
        $siswa = $this->siswaModel->login($nis, $password);

        if ($siswa) {

            unset($_SESSION['admin']);
            unset($_SESSION['id_admin']);
            unset($_SESSION['username']);
            unset($_SESSION['nama_lengkap']);

            $_SESSION['siswa'] = true;
            $_SESSION['nis'] = $siswa['nis'];
            $_SESSION['nama'] = $siswa['nama'];
            $_SESSION['kelas'] = $siswa['kelas'];

            header("Location: ../VIEW/SISWA/dasbord_siswa.php");
            exit();

        } else {

            $_SESSION['error'] = "NIS atau password salah!";

            header("Location: ../VIEW/auth/v_login.php");
            exit();
        }
    }


    // ==================================================
    // LOGIN ADMIN LAMA
    // ==================================================

    public function loginAdmin($username, $password)
    {
        $admin = $this->adminModel->login($username, $password);

        if ($admin) {

            unset($_SESSION['siswa']);
            unset($_SESSION['nis']);
            unset($_SESSION['nama']);
            unset($_SESSION['kelas']);

            $_SESSION['admin'] = true;
            $_SESSION['id_admin'] = $admin['id_admin'];
            $_SESSION['username'] = $admin['username'];
            $_SESSION['nama_lengkap'] = $admin['nama_lengkap'];

            header("Location: ../VIEW/ADMIN/v_dasbord_admin.php");
            exit();

        } else {

            $_SESSION['error'] = "Username atau password salah!";

            header("Location: ../VIEW/auth/v_login.php");
            exit();
        }
    }


    // ==================================================
    // REGISTER SISWA
    // ==================================================

    public function registerSiswa($data)
    {
        if (
            empty($data['nis']) ||
            empty($data['nama']) ||
            empty($data['kelas']) ||
            empty($data['email']) ||
            empty($data['password'])
        ) {

            $_SESSION['error'] = "Semua field harus diisi!";

            header("Location: ../VIEW/auth/v_register.php");
            exit();
        }


        // Cek NIS
        if ($this->siswaModel->cekNis($data['nis'])) {

            $_SESSION['error'] = "NIS sudah terdaftar!";

            header("Location: ../VIEW/auth/v_register.php");
            exit();
        }


        // Tambah siswa
        if ($this->siswaModel->tambahSiswa($data)) {

            $_SESSION['success'] = "Registrasi berhasil! Silakan login.";

            header("Location: ../VIEW/auth/v_login.php");
            exit();

        } else {

            $_SESSION['error'] = "Registrasi gagal!";

            header("Location: ../VIEW/auth/v_register.php");
            exit();
        }
    }


    // ==================================================
    // LOGOUT
    // ==================================================

    public function logout()
    {
        session_destroy();

        header("Location: ../VIEW/auth/v_login.php");
        exit();
    }
}


// ==================================================
// HANDLE REQUEST
// ==================================================

$auth = new AuthController();


// LOGIN SATU PINTU
if (isset($_POST['login'])) {

    $auth->login(
        $_POST['username'],
        $_POST['password']
    );


// REGISTER SISWA
} elseif (isset($_POST['register_siswa'])) {

    $auth->registerSiswa($_POST);


// LOGOUT
} elseif (isset($_GET['logout'])) {

    $auth->logout();
}

?>